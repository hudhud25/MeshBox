<?php
require_once('common.php');
UserUtils::log_out_user();
HTTPUtils::redirect('index.php');
?>